#!/usr/bin/python3
# -*- coding: utf-8 -*-

import sqlite3
from sqlite3 import Error
import os.path
import logging
import logging.config
import ipaddress
import json
import requests
import sys, getopt
import configparser
from requests.packages.urllib3.exceptions import InsecureRequestWarning

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

config = configparser.ConfigParser()
config.read('/home/flowmon/fgt-mitigation/etc/ag-config.ini')

# Time to live of DB entry in minutes (6 hours is default)
TTL = config.getint('script', 'decrease')
# verify TLS certificate, this can be enabled only when not a self-signed certificate is used
verify = config.getboolean('FortiGate', 'verify')
# IP of FW
IP = config['FortiGate']['IP']
# Address group on Firewall
GROUP = config['FortiGate']['GROUP']
# API key for fortigate
API_KEY = config['FortiGate']['API_KEY']
# HTTPS port
HTTPS = config['FortiGate']['HTTPS']

logging.config.fileConfig('/home/flowmon/fgt-mitigation/etc/logging.ini')

def create_connection():
    try:
        dbcon = sqlite3.connect(config['script']['DBFILE'], isolation_level=None)
        logging.debug('SQLite3 version connected: {}'.format(sqlite3.version))
    except Error as e:
        logging.error('Connection to DB failed: {}'.format(e))

    return dbcon
#end def create_connection()

# helper to build a good URL
def _url(path):
    return "https://" + IP + ":" + HTTPS + "/api/v2/cmdb/firewall/" + path
#def _url(path)

def update_ip(srcip, ttl):
    sql = 'UPDATE data SET ttl = ? WHERE ip = ?;'
    entry = (ttl,srcip)
    try:
        cur = dbcon.cursor()
        cur.execute(sql,entry)
        logging.debug('Updated TTL for IP {} '.format(srcip))
    except sqlite3.Error as e:
        logging.error('Failed to update IP record {}'.format(e))
        return False

    return cur.lastrowid
#def update_ip(srcip, ttl)

def delete_ip(srcip):
    sql = 'DELETE FROM data WHERE ip=?;'
    entry = (srcip,)
    try:
        cur = dbcon.cursor()
        cur.execute(sql,entry)
        logging.debug('Deleted DB IP entry {}'.format(srcip))
    except sqlite3.Error as e:
        logging.error('Failed to delete IP from DB {}'.format(e))
        return False

    return cur.lastrowid
#end def delete_ip(srcip)

def get_all_ip():
    sql = 'SELECT * FROM data;'
    try:
        cur = dbcon.cursor()
        cur.execute(sql)
    except sqlite3.Error as e:
        logging.error('Failed to retreive IPs from DB {}'.format(e))
        return False
    
    return cur.fetchall()
#end def get_all_ip()

# returns authentication token for the header
def get_header():
    return {'Authorization': 'Bearer ' + API_KEY, 'Content-Type': 'application/json'}

# Delete IP address to the Firewall
def remove_ip(eid):
    r = requests.delete(_url('address/Event ID {}'.format(eid)), headers=get_header(), verify=verify)
    if r.status_code == 200:
        logging.debug('IP address removed from the firewall.')
        return json.loads(r.content)
    else:
        logging.error('Cannot remove IP address object HTTP Code {} - {}'.format(r.status_code, r.content))

# get the information about group
def update_group(group):
    payload = json.dumps(group)
    r = requests.put(_url('addrgrp/{}'.format(GROUP)), data=payload, headers=get_header(), verify=verify)
    if r.status_code == 200:
        logging.debug('Group updated successfully.')
        return json.loads(r.content)
    else:
        logging.error('Cannot update group: {} - {}'.format(r.status_code, r.content))

def main(argv):
    global dbcon
    global IP
    global GROUP
    global HTTPS
    global API_KEY
    usage = """usage: ag-timeout.py <options>

Optional:
    --fw        IP / hostname of Fortigate firewall
    --port      HTTPS port on the Fortigate firewall
    --group     Name of Address group
    --key       FortiGate API key"""
    try:
        opts, args = getopt.getopt(argv,"f:p:g:k:h:",["fw=","port=","group=","key="])
    except getopt.GetoptError:
        print (usage)
        sys.exit(2)
    for opt, arg in opts:
        if opt in ("-h", "--help"):
            print (usage)
            sys.exit()
        elif opt in ("-f", "--fw"):
            IP = arg
        elif opt in ("-p", "--port"):
            HTTPS = arg
        elif opt in ("-g", "--group"):
            GROUP = arg
        elif opt in ("-k", "--key"):
            API_KEY = arg  

    dbcon = create_connection()

    logging.info('Starting timeout script')
    to_delete = []
    for record in get_all_ip():
        # decrease TTL
        if int(record[2]) > TTL:
            update_ip(record[0],(record[2] - TTL))
        # if <= TTL
        else:
            delete_ip(record[0])
            to_delete.append(record)
        # delete from table

    current_table = get_all_ip()
    # There are IPs in the list
    if current_table:
        gmember = []
        for member in current_table:
            gmember.append({'name': 'Event ID {}'.format(member[1])})
        
        # update group
        gcontent = {'name': GROUP, 'type': 'ipmask', 'member': gmember}
    else:
        gcontent = {'name': GROUP, 'type': 'ipmask', 'member': [{'name': 'none'}]}
    
    update_group(gcontent)

    for record in to_delete:
            remove_ip(record[1])

    logging.info('Everything is done')

if __name__ == "__main__":
       main(sys.argv[1:])