#!/usr/bin/python3
# -*- coding: utf-8 -*-

import sqlite3
from sqlite3 import Error
import os.path
import logging
import ipaddress
import json
import logging
import logging.config
import sys, getopt
import configparser
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

config = configparser.ConfigParser()
config.read('/home/flowmon/fgt-mitigation/etc/ag-config.ini')

# Time to live of DB entry in minutes (6 hours is default)
TTL = config.getint('script', 'TTL')
# verify TLS certificate, this can be enabled only when not a self-signed certificate is used
verify = config.getboolean('FortiGate', 'verify')
# IP of FW
IP = config['FortiGate']['IP']
# Address group on Firewall
GROUP = config['FortiGate']['GROUP']
# API key for fortigate
API_KEY = config['FortiGate']['API_KEY']
# HTTPS port
HTTPS = config['FortiGate']['HTTPS']

logging.config.fileConfig('/home/flowmon/fgt-mitigation/etc/logging.ini')

def create_connection():
    try:
        dbcon = sqlite3.connect(config['script']['DBFILE'], isolation_level=None)
        logging.debug('SQLite3 version connected: {}'.format(sqlite3.version))
    except Error as e:
        logging.error('Connection to DB failed: {}'.format(e))

    return dbcon
#end def create_connection()

# helper to build a good URL
def _url(path):
    return "https://" + IP + ":" + HTTPS + "/api/v2/cmdb/firewall/" + path
#def _url(path)

def create_table(table_sql):
    try:
        c = dbcon.cursor()
        c.execute(table_sql)
    except Error as e:
        logging.error('Cannot create a table: {}'.format(e))
#end def create_table(table_sql)

def db_init():
    sql_create = """CREATE TABLE IF NOT EXISTS data (
                        ip integer PRIMARY KEY,
                        event integer NOT NULL,
                        ttl integer NOT NULL
                    );"""

    if dbcon is not None:
        create_table(sql_create)
        logging.info('Persistent DB initialized')
    else:
        logging.error('Connection to database is not established')
#end def db_init():

def add_ip(srcip, eid, ttl):
    intip = int(ipaddress.IPv4Address(srcip))
    entry = (intip, eid, ttl)
    sql = 'INSERT INTO data(ip,event,ttl) VALUES(?,?,?);'
    try:
        cur = dbcon.cursor()
        cur.execute(sql,entry)
        logging.debug('Inseted succesffully new IP entry {}'.format(cur.rowcount))
    except sqlite3.Error as e:
        logging.error('Failed to insert IP to DB {}'.format(e))
        return False

    return cur.lastrowid
#def add_ip(srcip, eid, ttl)

def update_ip(srcip, ttl):
    intip = int(ipaddress.IPv4Address(srcip))
    entry = (intip, ttl)
    sql = 'UPDATE data SET ttl = ? WHERE ip = ?;'
    try:
        cur = dbcon.cursor()
        cur.execute(sql,entry)
        logging.debug('Updated TTL for IP {} '.format(srcip))
    except sqlite3.Error as e:
        logging.error('Failed to update IP record {}'.format(e))
        return False

    return cur.lastrowid
#def update_ip(srcip, ttl)

# returns authentication token for the header
def get_header():
    return {'Authorization': 'Bearer ' + API_KEY, 'Content-Type': 'application/json'}

# Add IP address to the Firewall
def post_ip(srcip, eid):
    payload = {'name' : 'Event ID {}'.format(eid), 'type': 'ipmask', 'subnet': '{} 255.255.255.255'.format(srcip)}
    payload = json.dumps(payload)
    r = requests.post(_url('address'), data=payload, headers=get_header(), verify=verify)
    if r.status_code == 200:
        logging.debug('IP address added to the firewall.')
        return json.loads(r.content)
    else:
        logging.error('Cannot add a new IP addrress object HTTP Code {} - {}'.format(r.status_code, r.content))

# get the information about group
def get_group():
        r = requests.get(_url('addrgrp/{}'.format(GROUP)), headers=get_header(), verify=verify)
        if r.status_code == 200:
            return json.loads(r.content)
        else:
            logging.error('Cannot get groups: {} - {}'.format(r.status_code, r.content))
            return False

# get the information about group
def update_group(group):
    payload = json.dumps(group)
    r = requests.put(_url('addrgrp/{}'.format(GROUP)), data=payload, headers=get_header(), verify=verify)
    if r.status_code == 200:
        logging.debug('Group updated successfully.')
        return json.loads(r.content)
    else:
        logging.error('Cannot update group: {} - {}'.format(r.status_code, r.content))

def main(argv):
    global dbcon
    global IP
    global GROUP
    global HTTPS
    global API_KEY
    usage = """usage: ag-mitigation.sh <options>

Optional:
    --fw        IP / hostname of Fortigate firewall
    --port      HTTPS port on the Fortigate firewall
    --group     Name of Address group
    --key       FortiGate API key"""
    try:
        opts, args = getopt.getopt(argv,"f:p:g:k:h:",["fw=","port=","group=","key="])
    except getopt.GetoptError:
        print (usage)
        sys.exit(2)
    for opt, arg in opts:
        if opt in ("-h", "--help"):
            print (usage)
            sys.exit()
        elif opt in ("-f", "--fw"):
            IP = arg
        elif opt in ("-p", "--port"):
            HTTPS = arg
        elif opt in ("-g", "--group"):
            GROUP = arg
        elif opt in ("-k", "--key"):
            API_KEY = arg

    dbcon = create_connection()
    db_init()

    logging.info('Starting mitigation script')
    # This part is taking care of looping through the stdin until EOF (Ctrl+D)
    for line in sys.stdin:
        event = line.rstrip().split('\t')
        receivedLength = len(event)
        
        logging.debug('Received #{} : {}'.format(receivedLength, event))
        # Check for length of received details to make sure we work with ADS detection
        if receivedLength >= 15:
            if 0 <= 16 <= len(event):
                event.append('')

            data = {'timestamp' : event[1],
                    'typeDesc'  : event[4],
                    'type' : event[3],
                    'severity' : event[8],
                    'id': event[0],
                    'source' : event[12],
                    'targets' : event[14],
                    'detail' : event[9],
                    'perspective' : event[7],
                    'netFlowSource' : event[15],
                    'userIdentity' : event[16]
                    }
        else:
            # Try to porecess as IDS event
            data = {'timestamp' : event[1],
                    'typeDesc'  : event[12],
                    'type' : 'IDSP',
                    'severity' : event[13],
                    'id': event[0],
                    'source' : event[3],
                    'targets' : event[5],
                    'detail' : event[9],
                    'perspective' : event[11],
                    'netFlowSource' : event[10],
                    'userIdentity' : ''
                    }
        try:
            logging.info('ID {} - type {} - source IP {}'.format(data["id"],data["type"],data["source"]))
            # attemtp to add IP to DB
            if add_ip(data["source"], data["id"], TTL):
                # add address to FW
                post_ip(data["source"], data["id"])
                # update address group
                gcontent = get_group()
                if gcontent:
                    new_group = gcontent["results"][0]
                    new_group["member"].append({'name': 'Event ID {}'.format(data["id"])})
                    update_group(new_group)
            else:
                update_ip(data["source"], TTL)
        except IndexError:
            logging.error('Incorrect number of parametres passed by ADS. {}'.format(event))

    logging.info('Everything is done')

if __name__ == "__main__":
       main(sys.argv[1:])